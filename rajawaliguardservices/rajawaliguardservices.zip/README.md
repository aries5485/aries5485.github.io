# Information
this project is using tailwindcss, you can see the documentation through this link : https://tailwindcss.com/